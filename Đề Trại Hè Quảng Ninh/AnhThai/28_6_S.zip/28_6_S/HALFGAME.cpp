#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
    freopen("HALFGAME.inp","r",stdin);
    freopen("HALFGAME.out","w",stdout);
    for (int t=5;t--;){
        int n;
        scanf("%d",&n);
        ll g = 0;
        while(n--){
            ll a;
            scanf("%lld",&a);
            if (a&1) g ^= (a+1)/2;
            else {
                for (int cnt=0;cnt<2;){
                    cnt += (a&1)==0;
                    a>>=1;
                }
                g ^= a;
            }
        }
        if (g) printf("yes\n");
        else printf("no\n");
    }
}
