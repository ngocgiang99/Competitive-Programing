#include<bits/stdc++.h>
using namespace std;

main(){
    freopen("GAME3579.inp","r",stdin);
    freopen("GAME3579.out","w",stdout);
    int t;
    cin>>t;
    while(t--){
        long long n;
        cin>>n;
        cout<<((n%12/3)?1:2)<<endl;
    }
}
