#include <bits/stdc++.h>
using namespace std;
const int maxs=105;
int n,s,a[maxs],giua[maxs],d;
bool kt;
long long t1,t2;
bool cmp(int x,int y)
{
    return x>y;
}
int main()
{
    ios_base::sync_with_stdio(0); cin.tie();
    freopen("POPNUMGAME.inp","r",stdin);
    freopen("POPNUMGAME.out","w",stdout);
    cin>>n;
    t1=t2=d=0;
    for(int k=1;k<=n;k++)
    {
        kt=1;
        cin>>s;
        if(s%2==0) kt=0;
        for(int i=1;i<=s;i++)
        {
            cin>>a[i];
            if(kt)
            {
                if(i<(s+1)/2) t1+=a[i];
                else {
                        if(i==(s+1)/2) giua[++d]=a[i];
                        else t2+=a[i];
                     }
            }
            else
            {
                if(i<=s/2) t1+=a[i];
                else t2+=a[i];
            }
         }
    }
    if(d!=0)
    {
        sort(giua+1,giua+d+1,cmp);
        for(int i=1;i<=d;i++)
            if(i%2==0) t2+=giua[i];
            else t1+=giua[i];
    }
    cout<<t1<<" "<<t2;
    return 0;
}
