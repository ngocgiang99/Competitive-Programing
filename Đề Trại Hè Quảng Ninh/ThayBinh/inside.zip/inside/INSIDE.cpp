#include <bits/stdc++.h>
#define maxn 100001
#define ft first
#define sc second

using namespace std;
typedef pair<int,int> II;

int n, p, q, r, s;
II a[maxn], b[maxn];

int ccw(II u,II v) {
    int64_t t=int64_t(u.ft)*v.sc - int64_t(u.sc)*v.ft;
    if (t>0) return 1;
    if (t<0) return -1;
    return 0;
}

bool cmp(II u,II v) {
    return (ccw(u,v)>0);
}

int main() {
    freopen("INSIDE.INP","r",stdin);
    freopen("INSIDE.OUT","w",stdout);
    scanf("%d", &n);
    int xP, yP; scanf("%d %d", &xP, &yP);
    p=0, q=0, r=0, s=0;
    for(int i=1;i<=n;++i) {
        int x, y; scanf("%d %d", &x, &y);
        x -= xP; y -= yP;
        if (y!=0) {
            if (y>0) a[++p]=II(x,y);
            else b[++q]=II(x,y);
        } else if (x!=0) {
            if (x>0) ++r; else ++s;
        }
    }
    sort(a+1,a+p+1,cmp);
    sort(b+1,b+q+1,cmp);
    int64_t ans=0;
    // Dem cac tam giac co mot dinh nam phan duong  truc hoanh
    int j=1;
    for(int i=1;i<=p;++i) {
        while (j<=q && ccw(a[i],b[j])>0) ++j;
        ans += int64_t(r)*(j-1);
    }
    // Dem cac tam giac co mot dinh nam phan am truc hoanh
    j=1;
    for(int i=1;i<=p;++i) {
        while (j<=q && ccw(a[i],b[j])>=0) ++j;
        ans += int64_t(s)*(q+1-j);
    }
    // Mot dinh phan a va hai dinh phan b
    int u=1, v=1;
    for(int i=1;i<=p;++i) {
        while (u<=q && ccw(a[i],b[u])>0) ++u;
        while (v<=q && ccw(a[i],b[v])>=0) ++v;
        ans += int64_t(u-1)*(q+1-v);
    }
    // Mot dinh phan b va hai dinh phan a
    u=1, v=1;
    for(int i=1;i<=q;++i) {
        while (u<=p && ccw(a[u],b[i])<0) ++u;
        while (v<=p && ccw(a[v],b[i])<=0) ++v;
        ans += int64_t(u-1)*(p+1-v);
    }
    printf("%I64d", ans);
}

