#include <bits/stdc++.h>
#define maxn 3001
#define ft first
#define sc second

using namespace std;
typedef pair<int,int> II;

int n, m, x[maxn], y[maxn];
II a[maxn];
int64_t ans;

int ccw(II u,II v) {
    int64_t t=int64_t(u.ft)*v.sc-int64_t(u.sc)*v.ft;
    if (t>0) return 1;
    if (t<0) return -1;
    return 0;
}

bool cmp(II u,II v) {
    return (ccw(u,v)>0);
}

void solve(int k) {
    m=0;
    for(int i=1;i<=n;++i) if (i!=k) {
        int u=x[i]-x[k], v=y[i]-y[k];
        if (v>0) a[++m]=II(u,v); else
            if (v==0 && u>0) a[++m]=II(u,v);
    }
    sort(a+1,a+m+1,cmp);
    II sum=II(0,0);
    for(int i=1;i<=m;++i) {
        sum.ft += a[i].ft;
        sum.sc += a[i].sc;
    }
    for(int i=1;i<=m;++i) {
        sum.ft -=a[i].ft, sum.sc -= a[i].sc;
        ans += int64_t(a[i].ft)*sum.sc - int64_t(a[i].sc)*sum.ft;
    }
}

int main() {
    freopen("sumarea.inp","r",stdin);
    freopen("sumarea.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;++i) scanf("%d %d", &x[i], &y[i]);
    ans=0;
    for(int i=1;i<=n;++i) solve(i);
    printf("%I64d",ans/2);
    if (ans%2) printf(".5"); else printf(".0");
}
